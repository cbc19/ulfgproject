package com.example.fategame;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;
import android.content.Context;
import android.content.ContentValues;
public class MyDBHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION =1;
    private static final String DATABASE_NAME="project_as.db";

    public static final String TABLE_SERVANT_STAT="servant_stat";
    public static final String COLUMN_SERVANT_ID="_servant_id";
    public static final String COLUMN_SERVANT_NAME="_servant_name";
    public static final String COLUMN_SERVANT_HP="_servant_hp";
    public static final String COLUMN_SERVANT_ATK="_servant_atk";
    public static final String COLUMN_FIRST_PHANTASM="_first_phantasm";
    public static final String COLUMN_SECOND_PHANTASM="_second_phantasm";
    public static final String COLUMN_FIRST_MANA="_first_mana";
    public static final String COLUMN_SECOND_MANA="_second_mana";
    public static final String COLUMN_PHY_DEF="_phy_def";
    public static final String COLUMN_MAG_DED="_mag_def";
    public static final String COLUMN_SERVANT_NAME2="_servant_name2";

    public static final String TABLE_USER_ID="user_id";
    public static final String COLUMN_USERNAME="_username";
    public static final String COLUMN_PASSWORD="_password";
    public static final String COLUMN_CURRENCY="_currency";

    public static final String TABLE_SERVANT_INFO="servant_info";
    public static final String COLUMN_PRIMARY="_primary";
    public static final String COLUMN_XP="_xp";

    public MyDBHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);

    }
    SQLiteDatabase dc;
    @Override
    public void onCreate(SQLiteDatabase db) {
        this.dc=db;
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_SERVANT_STAT);
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_USER_ID);
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_SERVANT_INFO);
        String query = " CREATE TABLE " + TABLE_SERVANT_STAT + "(" +
                COLUMN_SERVANT_ID + " INTEGER PRIMARY KEY ," +
                COLUMN_SERVANT_NAME + " TEXT ," +
                COLUMN_SERVANT_HP +" INTEGER," +
                COLUMN_SERVANT_ATK +" INTEGER ," +
                COLUMN_FIRST_PHANTASM +" TEXT ,"+
                COLUMN_SECOND_PHANTASM+" TEXT ,"+
                COLUMN_FIRST_MANA +" INTEGER ," +
                COLUMN_SECOND_MANA +" INTEGER ," +
                COLUMN_PHY_DEF +" INTEGER ," +
                COLUMN_MAG_DED +" INTEGER ," +
                COLUMN_SERVANT_NAME2 +" TEXT " +
                ");";
        db.execSQL(query);
        query = " CREATE TABLE " + TABLE_USER_ID + "(" +
                COLUMN_USERNAME + " TEXT PRIMARY KEY  ," +
                COLUMN_PASSWORD + " TEXT ," +
                COLUMN_CURRENCY +" INTEGER " +
                ");";
        db.execSQL(query);
        query = " CREATE TABLE " + TABLE_SERVANT_INFO + "(" +
                COLUMN_PRIMARY + " INTEGER PRIMARY KEY AUTOINCREMENT ," +
                COLUMN_USERNAME + " TEXT ," +
                COLUMN_SERVANT_ID +" INTEGER ," +
                COLUMN_XP +" INTEGER "+
                ");";
        db.execSQL(query);
        createStatTable(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_SERVANT_STAT);
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_USER_ID);
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_SERVANT_INFO);
        onCreate(db);
    }

    public void createStatTable(SQLiteDatabase db){
        db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_SERVANT_ID, 1);
        values.put(COLUMN_SERVANT_NAME,"Saber");
        values.put(COLUMN_SERVANT_HP,3892);
        values.put(COLUMN_SERVANT_ATK,105);
        values.put(COLUMN_FIRST_PHANTASM,"Avalon");
        values.put(COLUMN_SECOND_PHANTASM,"Excalibur");
        values.put(COLUMN_FIRST_MANA,24);
        values.put(COLUMN_SECOND_MANA,58);
        values.put(COLUMN_PHY_DEF,23);
        values.put(COLUMN_MAG_DED,30);
        values.put(COLUMN_SERVANT_NAME2,"Arthur");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 2);
        values.put(COLUMN_SERVANT_NAME,"Archer");
        values.put(COLUMN_SERVANT_HP,3934);
        values.put(COLUMN_SERVANT_ATK,93);
        values.put(COLUMN_FIRST_PHANTASM,"Rho Aias");
        values.put(COLUMN_SECOND_PHANTASM,"U.B.W.");
        values.put(COLUMN_FIRST_MANA,18);
        values.put(COLUMN_SECOND_MANA,62);
        values.put(COLUMN_PHY_DEF,22);
        values.put(COLUMN_MAG_DED,24);
        values.put(COLUMN_SERVANT_NAME2,"Shirou");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 3);
        values.put(COLUMN_SERVANT_NAME,"Lancer");
        values.put(COLUMN_SERVANT_HP,4868);
        values.put(COLUMN_SERVANT_ATK,103);
        values.put(COLUMN_FIRST_PHANTASM,"Gáe Buidhe");
        values.put(COLUMN_SECOND_PHANTASM,"Gáe Bolg");
        values.put(COLUMN_FIRST_MANA,22);
        values.put(COLUMN_SECOND_MANA,59);
        values.put(COLUMN_PHY_DEF,26);
        values.put(COLUMN_MAG_DED,18);
        values.put(COLUMN_SERVANT_NAME2,"Cú Chulainn");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 4);
        values.put(COLUMN_SERVANT_NAME,"Rider");
        values.put(COLUMN_SERVANT_HP,4716);
        values.put(COLUMN_SERVANT_ATK,86);
        values.put(COLUMN_FIRST_PHANTASM,"Via Expugnatio");
        values.put(COLUMN_SECOND_PHANTASM,"I.H.");
        values.put(COLUMN_FIRST_MANA,14);
        values.put(COLUMN_SECOND_MANA,58);
        values.put(COLUMN_PHY_DEF,23);
        values.put(COLUMN_MAG_DED,17);
        values.put(COLUMN_SERVANT_NAME2,"Iskandar");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 5);
        values.put(COLUMN_SERVANT_NAME,"Caster");
        values.put(COLUMN_SERVANT_HP,2434);
        values.put(COLUMN_SERVANT_ATK,70);
        values.put(COLUMN_FIRST_PHANTASM,"P's spellbook");
        values.put(COLUMN_SECOND_PHANTASM,"Rule breaker");
        values.put(COLUMN_FIRST_MANA,0);
        values.put(COLUMN_SECOND_MANA,60);
        values.put(COLUMN_PHY_DEF,12);
        values.put(COLUMN_MAG_DED,25);
        values.put(COLUMN_SERVANT_NAME2,"Medea");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 6);
        values.put(COLUMN_SERVANT_NAME,"Berserker");
        values.put(COLUMN_SERVANT_HP,10468);
        values.put(COLUMN_SERVANT_ATK,50);
        values.put(COLUMN_FIRST_PHANTASM,"Mad Enhancement");
        values.put(COLUMN_SECOND_PHANTASM,"Nine lives");
        values.put(COLUMN_FIRST_MANA,30);
        values.put(COLUMN_SECOND_MANA,60);
        values.put(COLUMN_PHY_DEF,28);
        values.put(COLUMN_MAG_DED,28);
        values.put(COLUMN_SERVANT_NAME2,"Heracles");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 7);
        values.put(COLUMN_SERVANT_NAME,"Assassin");
        values.put(COLUMN_SERVANT_HP,3164);
        values.put(COLUMN_SERVANT_ATK,85);
        values.put(COLUMN_FIRST_PHANTASM,"F. Inspiration");
        values.put(COLUMN_SECOND_PHANTASM,"D.I.");
        values.put(COLUMN_FIRST_MANA,21);
        values.put(COLUMN_SECOND_MANA,42);
        values.put(COLUMN_PHY_DEF,15);
        values.put(COLUMN_MAG_DED,15);
        values.put(COLUMN_SERVANT_NAME2,"Hassan(C.A)");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 8);
        values.put(COLUMN_SERVANT_NAME,"Saber");
        values.put(COLUMN_SERVANT_HP,5632);
        values.put(COLUMN_SERVANT_ATK,75);
        values.put(COLUMN_FIRST_PHANTASM,"Armor of Fafanir");
        values.put(COLUMN_SECOND_PHANTASM,"Balmung");
        values.put(COLUMN_FIRST_MANA,21);
        values.put(COLUMN_SECOND_MANA,58);
        values.put(COLUMN_PHY_DEF,29);
        values.put(COLUMN_MAG_DED,28);
        values.put(COLUMN_SERVANT_NAME2,"Siegfried");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 9);
        values.put(COLUMN_SERVANT_NAME,"Archer");
        values.put(COLUMN_SERVANT_HP,4238);
        values.put(COLUMN_SERVANT_ATK,120);
        values.put(COLUMN_FIRST_PHANTASM,"Gate of Babylon");
        values.put(COLUMN_SECOND_PHANTASM,"Enuma Elish");
        values.put(COLUMN_FIRST_MANA,38);
        values.put(COLUMN_SECOND_MANA,72);
        values.put(COLUMN_PHY_DEF,18);
        values.put(COLUMN_MAG_DED,18);
        values.put(COLUMN_SERVANT_NAME2,"Gilgamesh");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 10);
        values.put(COLUMN_SERVANT_NAME,"Lancer");
        values.put(COLUMN_SERVANT_HP,4648);
        values.put(COLUMN_SERVANT_ATK,107);
        values.put(COLUMN_FIRST_PHANTASM,"Gáe Bolg A.");
        values.put(COLUMN_SECOND_PHANTASM,"Gate of skye");
        values.put(COLUMN_FIRST_MANA,29);
        values.put(COLUMN_SECOND_MANA,64);
        values.put(COLUMN_PHY_DEF,25);
        values.put(COLUMN_MAG_DED,22);
        values.put(COLUMN_SERVANT_NAME2,"Scáthach");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 11);
        values.put(COLUMN_SERVANT_NAME,"Rider");
        values.put(COLUMN_SERVANT_HP,3548);
        values.put(COLUMN_SERVANT_ATK,81);
        values.put(COLUMN_FIRST_PHANTASM,"B.F. Andromeda");
        values.put(COLUMN_SECOND_PHANTASM,"Bellerophon");
        values.put(COLUMN_FIRST_MANA,25);
        values.put(COLUMN_SECOND_MANA,61);
        values.put(COLUMN_PHY_DEF,23);
        values.put(COLUMN_MAG_DED,20);
        values.put(COLUMN_SERVANT_NAME2,"Medusa");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 12);
        values.put(COLUMN_SERVANT_NAME,"Caster");
        values.put(COLUMN_SERVANT_HP,3298);
        values.put(COLUMN_SERVANT_ATK,91);
        values.put(COLUMN_FIRST_PHANTASM,"Sikera Usum");
        values.put(COLUMN_SECOND_PHANTASM,"H.G.B.");
        values.put(COLUMN_FIRST_MANA,28);
        values.put(COLUMN_SECOND_MANA,100);
        values.put(COLUMN_PHY_DEF,25);
        values.put(COLUMN_MAG_DED,25);
        values.put(COLUMN_SERVANT_NAME2,"Semiramis");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 13);
        values.put(COLUMN_SERVANT_NAME,"Berserker");
        values.put(COLUMN_SERVANT_HP,4988);
        values.put(COLUMN_SERVANT_ATK,90);
        values.put(COLUMN_FIRST_PHANTASM,"Knight of owner");
        values.put(COLUMN_SECOND_PHANTASM,"Arondight");
        values.put(COLUMN_FIRST_MANA,50);
        values.put(COLUMN_SECOND_MANA,59);
        values.put(COLUMN_PHY_DEF,27);
        values.put(COLUMN_MAG_DED,23);
        values.put(COLUMN_SERVANT_NAME2,"Lancelot");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 14);
        values.put(COLUMN_SERVANT_NAME,"Assassin");
        values.put(COLUMN_SERVANT_HP,3458);
        values.put(COLUMN_SERVANT_ATK,85);
        values.put(COLUMN_FIRST_PHANTASM,"Chronos Rose");
        values.put(COLUMN_SECOND_PHANTASM,"Phantasm Pun.");
        values.put(COLUMN_FIRST_MANA,15);
        values.put(COLUMN_SECOND_MANA,50);
        values.put(COLUMN_PHY_DEF,27);
        values.put(COLUMN_MAG_DED,20);
        values.put(COLUMN_SERVANT_NAME2,"Kiritsugu");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 15);
        values.put(COLUMN_SERVANT_NAME,"Saber");
        values.put(COLUMN_SERVANT_HP,4238);
        values.put(COLUMN_SERVANT_ATK,101);
        values.put(COLUMN_FIRST_PHANTASM,"Luminosite etern.");
        values.put(COLUMN_SECOND_PHANTASM,"La Pucelle");
        values.put(COLUMN_FIRST_MANA,29);
        values.put(COLUMN_SECOND_MANA,50);
        values.put(COLUMN_PHY_DEF,30);
        values.put(COLUMN_MAG_DED,28);
        values.put(COLUMN_SERVANT_NAME2,"Jeanne d'Arc");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 16);
        values.put(COLUMN_SERVANT_NAME,"Archer");
        values.put(COLUMN_SERVANT_HP,4652);
        values.put(COLUMN_SERVANT_ATK,84);
        values.put(COLUMN_FIRST_PHANTASM,"Eye of the mind");
        values.put(COLUMN_SECOND_PHANTASM,"Antares Snipe");
        values.put(COLUMN_FIRST_MANA,18);
        values.put(COLUMN_SECOND_MANA,62);
        values.put(COLUMN_PHY_DEF,25);
        values.put(COLUMN_MAG_DED,20);
        values.put(COLUMN_SERVANT_NAME2,"Chiron");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 17);
        values.put(COLUMN_SERVANT_NAME,"Lancer");
        values.put(COLUMN_SERVANT_HP,3646);
        values.put(COLUMN_SERVANT_ATK,65);
        values.put(COLUMN_FIRST_PHANTASM,"Lgd of Dracula");
        values.put(COLUMN_SECOND_PHANTASM,"Kazikli Bey");
        values.put(COLUMN_FIRST_MANA,35);
        values.put(COLUMN_SECOND_MANA,64);
        values.put(COLUMN_PHY_DEF,19);
        values.put(COLUMN_MAG_DED,25);
        values.put(COLUMN_SERVANT_NAME2,"Vlad");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 18);
        values.put(COLUMN_SERVANT_NAME,"Rider");
        values.put(COLUMN_SERVANT_HP,3550);
        values.put(COLUMN_SERVANT_ATK,83);
        values.put(COLUMN_FIRST_PHANTASM,"Trap of Argalia");
        values.put(COLUMN_SECOND_PHANTASM,"Hippogriff");
        values.put(COLUMN_FIRST_MANA,21);
        values.put(COLUMN_SECOND_MANA,52);
        values.put(COLUMN_PHY_DEF,19);
        values.put(COLUMN_MAG_DED,28);
        values.put(COLUMN_SERVANT_NAME2,"Astolfo");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 19);
        values.put(COLUMN_SERVANT_NAME,"Caster");
        values.put(COLUMN_SERVANT_HP,3216);
        values.put(COLUMN_SERVANT_ATK,81);
        values.put(COLUMN_FIRST_PHANTASM,"Numerology");
        values.put(COLUMN_SECOND_PHANTASM,"Golem Adam");
        values.put(COLUMN_FIRST_MANA,25);
        values.put(COLUMN_SECOND_MANA,100);
        values.put(COLUMN_PHY_DEF,12);
        values.put(COLUMN_MAG_DED,25);
        values.put(COLUMN_SERVANT_NAME2,"Avicebron");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 20);
        values.put(COLUMN_SERVANT_NAME,"Berserker");
        values.put(COLUMN_SERVANT_HP,4120);
        values.put(COLUMN_SERVANT_ATK,72);
        values.put(COLUMN_FIRST_PHANTASM,"Brtidal Chest");
        values.put(COLUMN_SECOND_PHANTASM,"Balsed tree");
        values.put(COLUMN_FIRST_MANA,19);
        values.put(COLUMN_SECOND_MANA,110);
        values.put(COLUMN_PHY_DEF,26);
        values.put(COLUMN_MAG_DED,16);
        values.put(COLUMN_SERVANT_NAME2,"Frankenstein");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 21);
        values.put(COLUMN_SERVANT_NAME,"Assassin");
        values.put(COLUMN_SERVANT_HP,3936);
        values.put(COLUMN_SERVANT_ATK,70);
        values.put(COLUMN_FIRST_PHANTASM,"Maria the Ripper");
        values.put(COLUMN_SECOND_PHANTASM,"The Mist");
        values.put(COLUMN_FIRST_MANA,22);
        values.put(COLUMN_SECOND_MANA,60);
        values.put(COLUMN_PHY_DEF,17);
        values.put(COLUMN_MAG_DED,18);
        values.put(COLUMN_SERVANT_NAME2,"Jack the Ripper");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 22);
        values.put(COLUMN_SERVANT_NAME,"Saber");
        values.put(COLUMN_SERVANT_HP,4738);
        values.put(COLUMN_SERVANT_ATK,103);
        values.put(COLUMN_FIRST_PHANTASM,"Secret of pedigree");
        values.put(COLUMN_SECOND_PHANTASM,"Clarent Blood");
        values.put(COLUMN_FIRST_MANA,15);
        values.put(COLUMN_SECOND_MANA,71);
        values.put(COLUMN_PHY_DEF,28);
        values.put(COLUMN_MAG_DED,25);
        values.put(COLUMN_SERVANT_NAME2,"Mordred");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 23);
        values.put(COLUMN_SERVANT_NAME,"Archer");
        values.put(COLUMN_SERVANT_HP,3918);
        values.put(COLUMN_SERVANT_ATK,80);
        values.put(COLUMN_FIRST_PHANTASM,"Phob. Catastrphe");
        values.put(COLUMN_SECOND_PHANTASM,"Metamorphisis");
        values.put(COLUMN_FIRST_MANA,23);
        values.put(COLUMN_SECOND_MANA,82);
        values.put(COLUMN_PHY_DEF,16);
        values.put(COLUMN_MAG_DED,16);
        values.put(COLUMN_SERVANT_NAME2,"Atalanta");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 24);
        values.put(COLUMN_SERVANT_NAME,"Lancer");
        values.put(COLUMN_SERVANT_HP,5828);
        values.put(COLUMN_SERVANT_ATK,110);
        values.put(COLUMN_FIRST_PHANTASM,"Brahamustra");
        values.put(COLUMN_SECOND_PHANTASM,"Vasavi Shakti");
        values.put(COLUMN_FIRST_MANA,28);
        values.put(COLUMN_SECOND_MANA,75);
        values.put(COLUMN_PHY_DEF,30);
        values.put(COLUMN_MAG_DED,27);
        values.put(COLUMN_SERVANT_NAME2,"Karna");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 25);
        values.put(COLUMN_SERVANT_NAME,"Rider");
        values.put(COLUMN_SERVANT_HP,6348);
        values.put(COLUMN_SERVANT_ATK,105);
        values.put(COLUMN_FIRST_PHANTASM,"Troias Tragidia");
        values.put(COLUMN_SECOND_PHANTASM,"romeus Kometes");
        values.put(COLUMN_FIRST_MANA,19);
        values.put(COLUMN_SECOND_MANA,68);
        values.put(COLUMN_PHY_DEF,30);
        values.put(COLUMN_MAG_DED,30);
        values.put(COLUMN_SERVANT_NAME2,"Achilles");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 26);
        values.put(COLUMN_SERVANT_NAME,"Caster");
        values.put(COLUMN_SERVANT_HP,4256);
        values.put(COLUMN_SERVANT_ATK,55);
        values.put(COLUMN_FIRST_PHANTASM,"The king's men");
        values.put(COLUMN_SECOND_PHANTASM,"First Folio");
        values.put(COLUMN_FIRST_MANA,15);
        values.put(COLUMN_SECOND_MANA,69);
        values.put(COLUMN_PHY_DEF,15);
        values.put(COLUMN_MAG_DED,15);
        values.put(COLUMN_SERVANT_NAME2,"Shakespear");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 27);
        values.put(COLUMN_SERVANT_NAME,"Berserker");
        values.put(COLUMN_SERVANT_HP,8200);
        values.put(COLUMN_SERVANT_ATK,65);
        values.put(COLUMN_FIRST_PHANTASM,"Honor of batt.");
        values.put(COLUMN_SECOND_PHANTASM,"Crying Warmon.");
        values.put(COLUMN_FIRST_MANA,30);
        values.put(COLUMN_SECOND_MANA,65);
        values.put(COLUMN_PHY_DEF,28);
        values.put(COLUMN_MAG_DED,15);
        values.put(COLUMN_SERVANT_NAME2,"Spartacus");
        db.insert(TABLE_SERVANT_STAT,null, values);

        values.put(COLUMN_SERVANT_ID, 28);
        values.put(COLUMN_SERVANT_NAME,"Assassin");
        values.put(COLUMN_SERVANT_HP,3258);
        values.put(COLUMN_SERVANT_ATK,50);
        values.put(COLUMN_FIRST_PHANTASM,"Febile Insp.");
        values.put(COLUMN_SECOND_PHANTASM,"D.I.");
        values.put(COLUMN_FIRST_MANA,30);
        values.put(COLUMN_SECOND_MANA,70);
        values.put(COLUMN_PHY_DEF,15);
        values.put(COLUMN_MAG_DED,15);
        values.put(COLUMN_SERVANT_NAME2,"Hassan(H.F.)");
        db.insert(TABLE_SERVANT_STAT,null, values);

        db.close();
    }
   /* public void addUser(user_id user) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, user.get_username());
        values.put(COLUMN_PASSWORD, user.get_password());
        values.put(COLUMN_CURRENCY, user.get_currency());
        SQLiteDatabase db = getWritableDatabase();
        db.insert(TABLE_USER_ID,null, values);
        db.close();
    }*/


    public void deleteUser(String user){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL(" DELETE FROM "+TABLE_USER_ID+" WHERE " + COLUMN_USERNAME + " =\"" + user +"\";" );
        db.close();
    }

    public void updateCurr(String user, int cur){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL(" UPDATE  "+TABLE_USER_ID+" SET " + COLUMN_CURRENCY + " =\"" + cur +"\"  WHERE "+ COLUMN_USERNAME + " =\""+ user+"\";" );
        db.close();
    }
    /*public user_id findUser(String use){
        user_id user=new user_id("","",1);
        SQLiteDatabase db=getWritableDatabase();
        String query="SELECT * FROM "+ TABLE_USER_ID + " WHERE "+ COLUMN_USERNAME +" =\""+use+"\";";
        Cursor c=db.rawQuery(query,null);
        c.moveToFirst();
        while(!c.isAfterLast()&&!c.isBeforeFirst()){
            if(c.getString(c.getColumnIndex(COLUMN_USERNAME))!= null){
                user.set_username(c.getString(c.getColumnIndex(COLUMN_USERNAME)));
                user.set_password(c.getString(c.getColumnIndex(COLUMN_PASSWORD)));
                user.set_currency(c.getColumnIndex(COLUMN_CURRENCY));
            }
            else{
                user.set_username("");
                user.set_password("");
                user.set_currency(0);
            }
            c.moveToNext();
        }
        db.close();
        return user;
    }*/
    boolean boolfindUser(String use){
        SQLiteDatabase db = getWritableDatabase();
        String query="SELECT * FROM "+ TABLE_USER_ID + " WHERE "+ COLUMN_USERNAME +" =\""+use+"\";";
        try {
            Cursor c=db.rawQuery(query,null);
            c.moveToFirst();
            while (!c.isAfterLast() && !c.isBeforeFirst()) {
                if (c.getString(c.getColumnIndex(COLUMN_USERNAME)) != null) {
                    db.close();
                    return true;
                }

                c.moveToNext();
            }
            db.close();
        }
        catch(Exception ex) {
            System.out.println("Thrown exception: " + ex.toString());
        }
        return false;
    }


    /*public String databaseToString(){
        String dbString ="";
        SQLiteDatabase db = getWritableDatabase();
        String query="SELECT * FROM "+ TABLE_SERVANT_STAT + " WHERE 1 ";

        //CURSOR POINTS TO A LOCATION TO YOUR RESULT
        Cursor c=db.rawQuery(query,null);
        //MOVE TO THE FIRST ROW IN YOUR RESULTS
        //c.moveToFirst();
        c.moveToFirst();
        while(!c.isAfterLast()&&!c.isBeforeFirst()){
            if(c.getString(c.getColumnIndex(COLUMN_SERVANT_ID))!= null){
                dbString+=c.getString(c.getColumnIndex(COLUMN_SERVANT_ID))+" "+c.getString(c.getColumnIndex(COLUMN_SERVANT_NAME))
                        +" "+c.getString(c.getColumnIndex(COLUMN_SERVANT_HP))+" "+c.getString(c.getColumnIndex(COLUMN_SERVANT_ATK))
                        +" "+c.getString(c.getColumnIndex(COLUMN_FIRST_PHANTASM))+" "+c.getString(c.getColumnIndex(COLUMN_SECOND_PHANTASM))
                        +" "+c.getString(c.getColumnIndex(COLUMN_FIRST_MANA))+" "+c.getString(c.getColumnIndex(COLUMN_SECOND_MANA))
                        +" "+c.getString(c.getColumnIndex(COLUMN_PHY_DEF))+" "+c.getString(c.getColumnIndex(COLUMN_MAG_DED))
                        +" "+c.getString(c.getColumnIndex(COLUMN_SERVANT_NAME2));
                dbString+="\n";

            }
            c.moveToNext();
        }
        query="SELECT * FROM "+ TABLE_USER_ID + " WHERE "+ COLUMN_USERNAME +" =\"ralph\";";
        c=db.rawQuery(query,null);
        c.moveToFirst();
        while(!c.isAfterLast()&&!c.isBeforeFirst()){
            if(c.getString(c.getColumnIndex(COLUMN_USERNAME))!= null){
                dbString+=c.getString(c.getColumnIndex(COLUMN_USERNAME)) +" "+c.getString(c.getColumnIndex(COLUMN_PASSWORD))+" "+c.getString(c.getColumnIndex(COLUMN_CURRENCY));
                dbString+="\n";
            }
            c.moveToNext();
        }
        db.close();
        return dbString;

    }*/
}
