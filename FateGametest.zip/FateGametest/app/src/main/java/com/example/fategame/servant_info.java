package com.example.fategame;

public class servant_info {
    private int _primary;
    private String _username;
    private int _servant_id;
    private int _xp;

    public servant_info(String _username, int _servant_id, int _xp) {
        this._username = _username;
        this._servant_id = _servant_id;
        this._xp = _xp;
    }

    public String get_username() {
        return _username;
    }

    public void set_username(String _username) {
        this._username = _username;
    }

    public int get_servant_id() {
        return _servant_id;
    }

    public void set_servant_id(int _servant_id) {
        this._servant_id = _servant_id;
    }

    public int get_xp() {
        return _xp;
    }

    public void set_xp(int _xp) {
        this._xp = _xp;
    }
}
