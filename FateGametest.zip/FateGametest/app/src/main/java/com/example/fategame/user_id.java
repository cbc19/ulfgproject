package com.example.fategame;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

import java.security.AccessController;

/*public class user_id {
    private String _username;
    private String _password;
    private int _currency;
    private Context c;

    public user_id(String _username, String _password, int _currency, Context co) {
        this._username = _username;
        this._password = _password;
        this._currency = _currency;
        c=co;
    }

    public user_id(){
        _username="";
        _password="";
        _currency=0;
    }

    public void set_username(String _username) {
        this._username = _username;
    }

    public void set_password(String _password) {
        this._password = _password;
    }

    public void set_currency(int _currency) {
        this._currency = _currency;
    }

    public String get_username() {
        return _username;
    }

    public String get_password() {
        return _password;
    }

    public int get_currency() {
        return _currency;
    }

    public static class userentry implements BaseColumns{
        public static final String TABLE_USER_ID="user_id";
        public static final String COLUMN_USERNAME="_username";
        public static final String COLUMN_PASSWORD="_password";
        public static final String COLUMN_CURRENCY="_currency";
    }

    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + userentry.TABLE_USER_ID + " (" +
                    userentry.COLUMN_USERNAME + " TEXT PRIMARY KEY, " + userentry.COLUMN_PASSWORD + " TEXT, " + userentry.COLUMN_CURRENCY + " INTEGER);";
    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + userentry.TABLE_USER_ID;

    public class DBHelper extends SQLiteOpenHelper{
        public static final int DATABASE_VERSION = 1;
        public static final String DATABASE_NAME = "project_as.db";

        public DBHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(SQL_CREATE_ENTRIES);
        }
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL(SQL_DELETE_ENTRIES);
            onCreate(db);
        }
        public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            onUpgrade(db, oldVersion, newVersion);
        }
    }

    DBHelper dbHelper = new DBHelper(c);

    public void adduser(user_id user){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(userentry.COLUMN_USERNAME, user.get_username());
        values.put(userentry.COLUMN_PASSWORD, user.get_password());
        values.put(userentry.COLUMN_CURRENCY, user.get_currency());
        db.insert(userentry.TABLE_USER_ID,null,values);
    }
}*/

