package com.example.fategame;

public class servant_stat {
    private int _servant_id;
    private String _servant_name;
    private int _servant_hp;
    private int _servant_atk;
    private String _first_phantasm;
    private String _second_phantasm;
    private int _first_mana;
    private int _second_mana;
    private int _phy_def;
    private int _mag_def;
    private int _servant_name2;

    public servant_stat() {
    }

    public servant_stat(int _servant_id, String _servant_name, int _servant_hp, int _servant_atk, String _first_phantasm, String _second_phantasm, int _first_mana, int _second_mana, int _phy_def, int _mag_def, int _servant_name2) {
        this._servant_id = _servant_id;
        this._servant_name = _servant_name;
        this._servant_hp = _servant_hp;
        this._servant_atk = _servant_atk;
        this._first_phantasm = _first_phantasm;
        this._second_phantasm = _second_phantasm;
        this._first_mana = _first_mana;
        this._second_mana = _second_mana;
        this._phy_def = _phy_def;
        this._mag_def = _mag_def;
        this._servant_name2 = _servant_name2;
    }

    public void set_servant_id(int _servant_id) {
        this._servant_id = _servant_id;
    }

    public void set_servant_name(String _servant_name) {
        this._servant_name = _servant_name;
    }

    public void set_servant_hp(int _servant_hp) {
        this._servant_hp = _servant_hp;
    }

    public void set_servant_atk(int _servant_atk) {
        this._servant_atk = _servant_atk;
    }

    public void set_first_phantasm(String _first_phantasm) {
        this._first_phantasm = _first_phantasm;
    }

    public void set_second_phantasm(String _second_phantasm) {
        this._second_phantasm = _second_phantasm;
    }

    public void set_first_mana(int _first_mana) {
        this._first_mana = _first_mana;
    }

    public void set_second_mana(int _second_mana) {
        this._second_mana = _second_mana;
    }

    public void set_phy_def(int _phy_def) {
        this._phy_def = _phy_def;
    }

    public void set_mag_def(int _mag_def) {
        this._mag_def = _mag_def;
    }

    public void set_servant_name2(int _servant_name2) {
        this._servant_name2 = _servant_name2;
    }

    public int get_servant_id() {
        return _servant_id;
    }

    public String get_servant_name() {
        return _servant_name;
    }

    public int get_servant_hp() {
        return _servant_hp;
    }

    public int get_servant_atk() {
        return _servant_atk;
    }

    public String get_first_phantasm() {
        return _first_phantasm;
    }

    public String get_second_phantasm() {
        return _second_phantasm;
    }

    public int get_first_mana() {
        return _first_mana;
    }

    public int get_second_mana() {
        return _second_mana;
    }

    public int get_phy_def() {
        return _phy_def;
    }

    public int get_mag_def() {
        return _mag_def;
    }

    public int get_servant_name2() {
        return _servant_name2;
    }
}